package com.genymobile.scrcpy;

public class ConfigurationException extends Exception {
    public ConfigurationException(String message) {
        super(message);
    }
}
